function h = heff_floatpath(chaosFun, x0, nSamples, tol)
%HEFF_FLOATPATH  路径一：浮点精度路径（有效密钥熵的可达状态计数）
%
% 原理
%   连续混沌映射在双精度下并非"连续"，其可达状态由尾数位宽决定。
%   设状态变量 x ∈ [0,1) 以 IEEE-754 双精度表示，则每个状态至多携带
%   m = 52 位有效尾数；但相邻两次迭代的可分辨位移需 ≥ eps(x) 才会产生
%   新的可区分状态。因此单变量序列在 nSamples 步内可区分状态数的上界为
%
%       |S| ≤ min( 2^m , nSamples · max(1, |f'|_max) )
%
%   若把 k 个初值各自独立枚举为一个密钥分量，则
%
%       H_float = k · log2( |S_var| )
%
%   本函数用数值方法估计 log2|S|：
%     (1) 迭代获得轨道，计算相邻迭代的一阶差分 δ_t = |x_{t+1} - x_t|；
%     (2) 统计 δ_t 中最小的"可分辨量" ε = min{ δ_t : δ_t > 0 }；
%     (3) 由 ε 给出状态网格间距，|S| = floor(1/ε)，并以 2^52 封顶。
%
% 输入
%   chaosFun —— 函数句柄，接受标量 x 返回下一标量（如 @(x) 4*x*(1-x)）
%   x0       —— 初值（标量或向量，向量视为多分量密钥）
%   nSamples —— 迭代步数
%   tol      —— 可分辨阈值下限（默认取 eps）
%
% 输出
%   h —— struct：.log2statesPerVar  .H_float_bits  .epsEst  .note

if nargin < 4 || isempty(tol), tol = eps; end
if nargin < 3 || isempty(nSamples), nSamples = 2e4; end

x0 = x0(:);
k  = numel(x0);
bitsPerVar = zeros(k,1);
epsEst = zeros(k,1);

for j = 1:k
    x = x0(j);
    tr = zeros(nSamples,1);
    for t = 1:nSamples
        x = chaosFun(x);
        % 数值防溢出：轨道若逃逸出 [0,1] 则截断（双精度混沌的常见病）
        if ~isfinite(x), x = 0.5; end
        x = mod(x, 1);  if x < 0, x = x + 1; end
        tr(t) = x;
    end
    d = abs(diff(tr));
    d = d(d > 0);
    if isempty(d)
        epsEst(j) = 1;                      % 轨道恒定：无可分辨状态
    else
        epsEst(j) = max(min(d), tol);       % 可分辨下限
    end
    nState = min( floor(1/epsEst(j)), 2^52 );
    bitsPerVar(j) = log2(max(nState, 1));
end

h = struct();
h.log2statesPerVar = bitsPerVar;
h.H_float_bits     = sum(bitsPerVar);
h.epsEst           = epsEst;
h.note = sprintf(['浮点精度路径：%d 个初值分量，单个分量可分辨状态上界 ' ...
                  'log2|S| = %s bit'], k, mat2str(round(bitsPerVar',2)));
end
