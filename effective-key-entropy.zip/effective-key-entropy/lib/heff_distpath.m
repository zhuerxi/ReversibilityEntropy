function h = heff_distpath(encFunc, keySampler, plainFeat, nDist, nKeys, alpha)
%HEFF_DISTPATH  路径三：可区分性路径（由区分优势反推可区分密钥数）
%
% 原理
%   有效密钥空间的定义是"能被有效区分器分辨的密钥集合规模"：
%
%       H_eff = log2 |{ k : 存在区分器 D, Adv_D(k) > 0 }|
%
%   本函数用统计区分器近似该定义：
%     (1) 从 keySampler 独立采样 nKeys 个密钥；
%     (2) 对每个密钥，用 encFunc 加密同一明文，提取密文特征向量；
%     (3) 以特征向量的经验分布在密钥间做最近邻判别——若两个密钥产生的
%         特征向量不可区分（距离低于噪声水平），则这两个密钥"实际等价"；
%     (4) 统计等价类的个数 K_eff，令 H_eff = log2(K_eff)。
%
%   若同一明文在不同密钥下产生的密文特征能两两区分，则 K_eff = nKeys，
%   说明这 nKeys 个密钥都"有效"；反之 K_eff 显著小于 nKeys 说明存在
%   密钥塌缩（不同密钥给出行为相同的密文）。
%
% 输入
%   encFunc    —— 函数句柄 @(key) 返回密文（或密文特征向量）
%   keySampler —— 函数句柄 @(i) 返回第 i 个密钥（可解析生成以支持大密钥空间）
%   plainFeat  —— 预留参数（当前未使用，保持接口一致性）
%   nDist      —— 等价判定的距离样本数（默认 4）
%   nKeys      —— 采样密钥数（默认 500）
%   alpha      —— 等价阈值（相对尺度，默认 0.05，即特征间相对距离 < 5% 判为等价）
%
% 输出
%   h —— struct：.nKeys  .K_eff  .H_dist_bits  .collapseRatio  .featDim

if nargin < 4 || isempty(nDist),  nDist = 4;    end
if nargin < 5 || isempty(nKeys),  nKeys = 500;  end
if nargin < 6 || isempty(alpha),  alpha = 0.05; end
if nargin < 3, plainFeat = []; end

% ---- 提取每个密钥的密文特征 ----
F = [];
for i = 1:nKeys
    k = keySampler(i);
    c = encFunc(k);
    f = cipher_features(c);
    if isempty(F)
        F = zeros(nKeys, numel(f));
    end
    F(i,:) = f(:)';
end
featDim = size(F,2);

% ---- 特征标准化（消除量纲影响） ----
mu = mean(F,1);  sd = std(F,0,1);  sd(sd < eps) = 1;
Z = (F - mu) ./ sd;

% ---- 等价类划分：以相对距离阈值做单链聚类 ----
% 尺度参考：全部两两距离的中位数
if nKeys > 1
    D = pdist(Z);
    dMed = median(D);
else
    dMed = 1;
end
if dMed < eps, dMed = 1; end
thr = alpha * dMed;

% 单链聚类（并查集）
parent = 1:nKeys;
for i = 1:nKeys
    for j = i+1:nKeys
        if norm(Z(i,:) - Z(j,:)) <= thr
            parent = union_find(parent, i, j);
        end
    end
end
roots = zeros(1,nKeys);
for i = 1:nKeys, roots(i) = find_root(parent, i); end
K_eff = numel(unique(roots));

h = struct();
h.nKeys          = nKeys;
h.K_eff          = K_eff;
h.H_dist_bits    = log2(max(K_eff,1));
h.collapseRatio  = 1 - K_eff/max(nKeys,1);
h.featDim        = featDim;
h.note = sprintf(['可区分性路径：采样 %d 个密钥，等价类 %d 个，' ...
                  'H_dist = %.2f bit，塌缩率 %.1f%%'], ...
                  nKeys, K_eff, h.H_dist_bits, 100*h.collapseRatio);
end

% ----------------------------------------------------------------------
function f = cipher_features(c)
%CIPHER_FEATURES  密文的低维可区分特征（统计指纹）
c = double(c(:));
f = [ entropy_u8(c), ...              % 一阶熵
      mean(c), std(c), ...            % 一、二阶矩
      mean(abs(diff(c))), ...         % 相邻差绝对均值（局部相关性）
      sum(mod(c(1:end-1),2) ~= mod(c(2:end),2)) / max(numel(c)-1,1), ...  % 符号翻转率
      sum(c == 0)/numel(c), ...       % 零值占比
      sum(c == 255)/numel(c) ];       % 满值占比
end

function H = entropy_u8(c)
% 256 桶直方图熵
p = histcounts(c, 0:256) / numel(c);
p = p(p > 0);
H = -sum(p .* log2(p));
end

function p = union_find(p, i, j)
% 秩压缩合并
ri = find_root(p,i); rj = find_root(p,j);
if ri ~= rj, p(rj) = ri; end
end

function r = find_root(p, i)
r = i;
while p(r) ~= r, r = p(r); end
% 路径压缩
while p(i) ~= r, nxt = p(i); p(i) = r; i = nxt; end
end
