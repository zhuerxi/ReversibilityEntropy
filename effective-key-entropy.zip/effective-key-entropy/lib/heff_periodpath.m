function h = heff_periodpath(chaosFun, x0, maxLag, nSamples)
%HEFF_PERIODPATH  路径二：序列周期路径（有效密钥熵的动力学上界）
%
% 原理
%   混沌系统的"轨道长度"在有限精度下是有限的。设实际周期为 T，则由该
%   序列派生的密钥流至多提供 log2(T) 比特的独立熵——超出部分只是重复。
%   这构成有效密钥熵的一条独立上界：
%
%       H_period = log2(T)
%
%   本函数用两种互补手段估计 T：
%     (1) 重复检测：对序列做自相关式的首次重合检测（受 maxLag 限制）；
%     (2) 线性复杂度：对序列的二进制位平面做 Berlekamp-Massey，得到
%         线性复杂度 LC；若 LC ≈ nSamples/2，视为"无短周期"（通过），
%         否则视为存在短周期（不通过）。
%
% 输入
%   chaosFun —— 函数句柄
%   x0       —— 初值
%   maxLag   —— 最长检测滞后（默认 1e4）
%   nSamples —— 迭代步数（默认 max(4*maxLag, 2e4)）
%
% 输出
%   h —— struct：.T_detect  .log2T  .LC  .LCratio  .passLFSR

if nargin < 3 || isempty(maxLag),  maxLag = 1e4; end
if nargin < 4 || isempty(nSamples), nSamples = max(4*maxLag, 2e4); end

x = x0;
tr = zeros(nSamples,1);
for t = 1:nSamples
    x = chaosFun(x);
    if ~isfinite(x), x = 0.5; end
    x = mod(x,1); if x < 0, x = x + 1; end
    tr(t) = x;
end

% ---- (1) 首次重合检测 ----
T = NaN;
if nSamples > maxLag
    head = tr(1);                       % 用首元素做锚点
    for lag = 1:min(maxLag, nSamples-1)
        % 允许 1e-12 容差：双精度下真正的"同一状态"应为按位相同
        if abs(tr(lag+1) - head) < 1e-12
            T = lag; break;
        end
    end
end
if isnan(T), T = nSamples; end          % 未检出 => 以样本长度为下界
log2T = log2(T);

% ---- (2) 线性复杂度（对中间位平面） ----
bits = bitand(uint32(floor(tr * 2^32)), uint32(1));   % 最低位平面
bits = double(bits(:)');
LC = berlekamp_massey(bits);
LCratio = LC / numel(bits);

h = struct();
h.T_detect  = T;
h.log2T     = log2T;
h.LC        = LC;
h.LCratio   = LCratio;
h.passLFSR  = LCratio > 0.4;            % 经验阈值：>0.4 视为无短周期
h.note = sprintf(['周期路径：检出周期 T=%d (log2T=%.2f bit)，' ...
                  '线性复杂度 LC=%d (LC/n=%.3f)'], T, log2T, LC, LCratio);
end

% ----------------------------------------------------------------------
function LC = berlekamp_massey(s)
%BERLEKAMP_MASSEY  二元序列的最小线性反馈移位寄存器长度
s = double(s(:))';
n = numel(s);
c = zeros(1,n); c(1) = 1;       % 连接多项式
b = zeros(1,n); b(1) = 1;
L = 0; m = 1; bb = 1;
for i = 1:n
    d = s(i);
    for j = 1:L
        d = mod(d + c(j+1)*s(i-j), 2);
    end
    if d == 1
        t = c;
        shift = [zeros(1,m) b(1:end-m)];
        c(1:numel(shift)) = mod(c(1:numel(shift)) + shift, 2);
        if 2*L <= i-1
            L = i - L; b = t; m = 1; bb = d;
        else
            m = m + 1;
        end
    else
        m = m + 1;
    end
end
LC = L;
end
