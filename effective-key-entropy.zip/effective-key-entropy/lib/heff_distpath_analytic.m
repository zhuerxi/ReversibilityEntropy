function h = heff_distpath_analytic(chaosFun, x0, nSamples)
%HEFF_DISTPATH_ANALYTIC  路径三（解析版）：密钥扰动的可传播性估计有效熵
%
% 为什么不用采样法
%   采样法（heff_distpath）需要给定一个采样上限 nKeys，得到的 H_dist 天然
%   被 log2(nKeys) 封顶——当三条路径用于"收敛性检验"时，采样上限会变成
%   人为的假上界，使路径三系统性偏低。本函数改用解析/递推口径，避免该缺陷。
%
% 原理
%   密钥熵的物理意义是"能产生可区分密文的独立密钥位数"。在双精度浮点实现
%   下，初值的可分辨精度是 eps(x) ≈ 2^-52·x。若对初值施加 2^-p 量级的扰动
%   （p 越大扰动越精细），该扰动经 n 步混沌迭代后被放大 |(f^n)'| 倍。
%   只有当放大后的差异超过双精度的可分辨阈值（~2^-52）时，这个扰动位才
%   "真实生效"——否则加密输出完全相同，该位属于无效密钥位。
%
%   条件：2^-p · |(f^n)'| ≥ 2^-52  ⟺  p ≤ 52 + log2|(f^n)'|
%   因此有效位数上界
%         H_dist = min( 52,  52 + log2|(f^n)'| )
%   取 n = nSamples（最长链），并用数值方法估计 |(f^n)'| 的增长。
%
%   对大多数混沌映射 |(f^n)'| 随 n 指数增长（Lyapunov 指数 λ > 0），故
%   52 + log2|(f^n)'| 很快超过 52，此时 H_dist 饱和于双精度极限 52 bit。
%   这正是"浮点实现下有效密钥熵被机器精度封顶"这一定性结论的定量刻画。
%
% 输入
%   chaosFun —— 函数句柄
%   x0       —— 初值
%   nSamples —— 迭代步数（默认 3e4）
%
% 输出
%   h —— struct：.lyap  .H_dist_bits  .nEffBits  .nTrials  .note

if nargin < 3 || isempty(nSamples), nSamples = 3e4; end

% ---- 用两个极近轨道估计 Lyapunov 指数 ----
d0 = 1e-10;
x1 = x0;  x2 = x0 + d0;
logSum = 0;  cnt = 0;  nEff = 0;
prevOk = true;
for t = 1:nSamples
    x1 = chaosFun(x1);  x2 = chaosFun(x2);
    if ~isfinite(x1), x1 = 0.5; end
    if ~isfinite(x2), x2 = 0.5; end
    d = abs(x2 - x1);
    if d > 1e-16 && d < 1e-2
        logSum = logSum + log2(d/d0);
        cnt = cnt + 1;
    end
    % 统计"扰动尚未被机器精度吞掉"的步数（有效传播长度）
    if d > 1e-15, nEff = t; end
    if ~prevOk && d <= 1e-15, break; end
    prevOk = d > 1e-15;
end
lyap = logSum / max(cnt,1);              % 每步 log2 放大倍数

% ---- 有效位数 ----
% 由 2^-p · 2^{lyap·n} ≥ 2^-52 解出 p 的上界
nChain = max(nEff, 1);
pBound = 52 + lyap * nChain;
H_dist = min(52, max(pBound, 0));

% nEffBits：扰动实际存活的比特数（受放大与机器精度共同约束）
nEffBits = H_dist;

h = struct();
h.lyap         = lyap;
h.H_dist_bits  = H_dist;
h.nEffBits     = nEffBits;
h.nTrials      = nChain;
h.note = sprintf(['可区分性路径（解析）：Lyapunov 指数 %.4f bit/step，' ...
                  '扰动存活链长 %d，H_dist = %.2f bit'], lyap, nChain, H_dist);
end
