function R = run_criteria_audit(which)
%RUN_CRITERIA_AUDIT  L1 统计合规层的标准化协议与越界值检测
%
% 用法：run_criteria_audit()     —— 全部
%       run_criteria_audit(1)    —— 仅 E1（NPCR/UACI 多次测量）
%       run_criteria_audit(3)    —— 仅 E3（NPCR 与密钥熵相关性）
%RUN_CRITERIA_AUDIT  L1 统计合规层的标准化协议与越界值检测
%
% 背景：NPCR / UACI 是图像加密领域最常被引用的两个指标，但该领域长期存在
% 两类系统性误用：
%   (1) 只报"接近理想值"而不给置信区间与显著性检验，单次测量被当作定论；
%   (2) 把"高 NPCR"当作安全性的充分证据——实际上 NPCR 只衡量扩散充分性，
%       与密钥熵无关。
%
% 本实验用三个方案对照，给出可复现的标准化协议：
%   P1 XOR-only       逐像素异或（几乎无扩散）
%   P2 Row-diffuse    仅行内反馈扩散
%   P3 Full-diffuse   行列双重反馈扩散（充分扩散）
%
%   E1  单图多次测量的经验分布 —— 展示单次测量的随机波动幅度
%   E2  与理论理想值的假设检验 —— NPCR/UACI 的 z 检验与 p 值
%   E3  NPCR 与密钥熵的相关性  —— 检验高 NPCR 是否等价于密钥空间充分
%
% 输出：out/audit_npcr_uaci.csv、out/audit_hypothesis.csv、
%       out/audit_correlation.csv、out/fig_audit.*

outdir = fullfile(fileparts(fileparts(mfilename('fullpath'))),'out');
if ~exist(outdir,'dir'), mkdir(outdir); end
rng(20261002);
if nargin < 1 || isempty(which), which = 0; end
doE1 = (which == 0 || which == 1);
doE3 = (which == 0 || which == 3);

imgs = testset_standard();
fprintf('\n载入测试图像 %d 张\n', numel(imgs));

schemes = {'P1_XOR_only','P2_Row_diffuse','P3_Full_diffuse'};
nSch = numel(schemes);

if doE1
%% ---------- E1：单图多次测量的经验分布 ----------
fprintf('\n===== E1：NPCR/UACI 单图多次测量（每方案每图 200 次） =====\n');
nRep = 200;
T1 = {};
for k = 1:numel(imgs)
    I = imgs(k).I; n = size(I,1);
    for s = 1:nSch
        npcrV = zeros(nRep,1); uaciV = zeros(nRep,1);
        for r = 1:nRep
            J = I;  p = randi(numel(J));
            J(p) = uint8(mod(double(J(p)) + randi([1 255]), 256));
            kk = uint8(mod(round(255*rand(n,n)), 256));
            C1 = apply_scheme(I,  kk, s);
            C2 = apply_scheme(J,  kk, s);   % 同一密钥：只变化明文
            [np, ua] = npcr_uaci(C1, C2);
            npcrV(r) = np;  uaciV(r) = ua;
        end
        T1(end+1,:) = {imgs(k).name, schemes{s}, mean(npcrV), std(npcrV), ...
                       mean(uaciV), std(uaciV), max(npcrV)-min(npcrV), nRep}; %#ok<AGROW>
    end
end
T1tab = cell2table(T1, 'VariableNames', ...
    {'image','scheme','NPCR_mean','NPCR_std','UACI_mean','UACI_std','NPCR_range','nRep'});
writetable(T1tab, fullfile(outdir,'audit_npcr_uaci.csv'), 'Encoding','UTF-8');

fprintf('%-14s %-16s %-18s %-18s\n','图像','方案','NPCR 均值±标准差','UACI 均值±标准差');
for i = 1:height(T1tab)
    fprintf('%-14s %-16s %7.4f±%-8.4f %7.4f±%-8.4f\n', T1tab.image{i}, T1tab.scheme{i}, ...
        T1tab.NPCR_mean(i), T1tab.NPCR_std(i), T1tab.UACI_mean(i), T1tab.UACI_std(i));
end

%% ---------- E2：与理论理想值的假设检验 ----------
fprintf('\n===== E2：与理论理想值的假设检验 =====\n');
npcrStar = 255/256;
uaciStar = 257/768;
fprintf('理论理想值：NPCR* = %.6f，UACI* = %.6f\n', npcrStar, uaciStar);
fprintf('%-14s %-16s %-14s %-14s %s\n','图像','方案','z(NPCR)','z(UACI)','结论(α=0.05)');

T2 = {};
for i = 1:height(T1tab)
    sdN = max(T1tab.NPCR_std(i), eps);  sdU = max(T1tab.UACI_std(i), eps);
    zN = (T1tab.NPCR_mean(i) - npcrStar) / sdN;
    zU = (T1tab.UACI_mean(i) - uaciStar) / sdU;
    if abs(zN) < 1.96 && abs(zU) < 1.96
        concl = '与理想值无显著差异';
    elseif abs(zN) >= 1.96 && abs(zU) < 1.96
        concl = 'NPCR 显著偏离';
    elseif abs(zN) < 1.96 && abs(zU) >= 1.96
        concl = 'UACI 显著偏离';
    else
        concl = '两者均显著偏离';
    end
    T2(end+1,:) = {T1tab.image{i}, T1tab.scheme{i}, zN, zU, concl}; %#ok<AGROW>
end
T2tab = cell2table(T2, 'VariableNames', {'image','scheme','z_NPCR','z_UACI','conclusion'});
writetable(T2tab, fullfile(outdir,'audit_hypothesis.csv'), 'Encoding','UTF-8');

% 汇总：各方案达到"无显著差异"的图像数
fprintf('\n各方案通过率（|z| < 1.96 的比例）：\n');
for s = 1:nSch
    sub = T2tab(strcmp(T2tab.scheme, schemes{s}), :);
    pass = nnz(abs(sub.z_NPCR) < 1.96 & abs(sub.z_UACI) < 1.96);
    fprintf('  %-16s %d/%d\n', schemes{s}, pass, height(sub));
end

end
%% ---------- E3：NPCR 与密钥熵的相关性检验 ----------
% 核心论点：NPCR 衡量扩散充分性，与密钥空间大小无关。
% 做法：固定扩散逻辑（P3），构造"有效密钥位数"受控的方案族。
if doE3
%
% 关键设计：有效密钥熵必须真正受控，否则无法隔离变量。
%   本实验用一个**长度为 nBits 的短种子**经伪随机扩展生成整幅密钥流。
%   种子位数从 4 增至 32，则无论图像多大，密钥流实际承载的独立熵都是 nBits。
%   由于总熵按 log2(2^nBits) = nBits 计，NPCR 若与熵无关，应不随 nBits 变化。
fprintf('\n===== E3：NPCR 与密钥熵的相关性检验 =====\n');
nSet = 40;
I = imgs(1).I;  n = size(I,1);
bitEnt = round(linspace(4, 32, nSet));
npcrArr = zeros(nSet,1);
for s = 1:nSet
    nBits = bitEnt(s);
    % 用 nBits 位种子生成整幅密钥流（种子的熵即密钥流的全部独立熵）
    seed = randi([0 2^nBits - 1], 1, 1);
    fprintf_seed = double(seed) + 1;
    % LCG 扩展：从种子生成 N 个字节
    a = 1664525; c = 1013904223; m = 2^32;
    v = mod(a*fprintf_seed + c, m);
    ks = zeros(n*n, 1, 'uint8');
    for t = 1:(n*n)
        v = mod(a*v + c, m);
        ks(t) = uint8(mod(floor(v / 2^24), 256));
    end
    kk = reshape(ks, n, n);

    C1 = apply_scheme(I, kk, 3);
    J = I; p = randi(numel(J)); J(p) = uint8(mod(double(J(p))+1,256));
    C2 = apply_scheme(J, kk, 3);
    [np, ~] = npcr_uaci(C1, C2);
    npcrArr(s) = np;
end
[rho, pval] = corr(bitEnt(:), npcrArr, 'Type','Spearman');
fprintf('密钥熵范围 %.0f–%.0f bit，NPCR 范围 %.4f–%.4f\n', ...
    min(bitEnt), max(bitEnt), min(npcrArr), max(npcrArr));
fprintf('Spearman 相关系数 ρ = %+.4f，p = %.4f\n', rho, pval);
if pval > 0.05
    fprintf('结论：NPCR 与密钥熵无显著相关（p > 0.05）——\n');
    fprintf('      高 NPCR 不能作为密钥空间充分的证据。\n');
else
    fprintf('结论：存在显著相关（p <= 0.05），需进一步排查混杂因素。\n');
end
T3tab = table(rho, pval, min(bitEnt), max(bitEnt), mean(npcrArr), std(npcrArr), ...
    'VariableNames',{'spearman_rho','p_value','ent_min_bit','ent_max_bit','NPCR_mean','NPCR_std'});
writetable(T3tab, fullfile(outdir,'audit_correlation.csv'), 'Encoding','UTF-8');
end

%% ---------- 落盘与出图 ----------
% 若本次只跑了部分子实验，则从已有 CSV 读回缺失的表，保证出图与保存完整
if ~exist('T1tab','var') || isempty(T1tab)
    T1tab = readtable(fullfile(outdir,'audit_npcr_uaci.csv'), 'Encoding','UTF-8');
end
if ~exist('T2tab','var') || isempty(T2tab)
    T2tab = readtable(fullfile(outdir,'audit_hypothesis.csv'), 'Encoding','UTF-8');
end
if ~exist('T3tab','var') || isempty(T3tab)
    T3tab = readtable(fullfile(outdir,'audit_correlation.csv'), 'Encoding','UTF-8');
end
if ~exist('npcrStar','var'), npcrStar = 255/256; end
if ~exist('bitEnt','var') || ~exist('npcrArr','var')
    bitEnt = []; npcrArr = [];
end
if ~exist('rho','var'), rho = T3tab.spearman_rho(1); end
if ~exist('pval','var'), pval = T3tab.p_value(1); end

fgr = figure('Visible','off','Position',[100 100 1080 350]);

subplot(1,2,1);
cols = [0.75 0.30 0.25; 0.83 0.53 0.18; 0.20 0.42 0.66];
hold on;
for s = 1:nSch
    sub = T1tab(strcmp(T1tab.scheme, schemes{s}), :);
    errorbar(1:height(sub), sub.NPCR_mean, sub.NPCR_std, 'o-', ...
        'Color',cols(s,:),'MarkerFaceColor',cols(s,:),'MarkerSize',3.5);
end
yline(npcrStar, '--', 'Color',[0.3 0.3 0.3], 'LineWidth',1.1);
set(gca,'XTick',1:height(imgs),'XTickLabel',{imgs.name},'FontSize',7); xtickangle(45);
ylabel('NPCR'); ylim([0 1.05]);
legend([schemes, {'理论理想值'}], 'Location','southeast','FontSize',7);
title('(a) 三种方案的 NPCR 波动','FontSize',10);
grid on; box off;

subplot(1,2,2);
if ~isempty(bitEnt)
    scatter(bitEnt, npcrArr, 26, 'filled', 'MarkerFaceColor',[0.30 0.58 0.35]);
    hold on;
    pp = polyfit(bitEnt(:), npcrArr, 1);
    xx = linspace(min(bitEnt), max(bitEnt), 50);
    plot(xx, polyval(pp,xx), '--', 'Color',[0.5 0.5 0.5]);
end
xlabel('有效密钥熵 (bit)'); ylabel('NPCR'); ylim([0 1.05]);
title(sprintf('(b) NPCR vs 密钥熵：\\rho = %+.3f (p = %.3f)', rho, pval),'FontSize',10);
grid on; box off;

exportgraphics(fgr, fullfile(outdir,'fig_audit.tif'), 'Resolution', 400);
exportgraphics(fgr, fullfile(outdir,'fig_audit.png'), 'Resolution', 200);
close(fgr);

save(fullfile(outdir,'audit_all.mat'),'T1tab','T2tab','T3tab');
R = struct('measurements',T1tab,'hypothesis',T2tab,'correlation',T3tab);
fprintf('\n[已写出] audit_*.csv 与 fig_audit.tif/png\n');
end

% ======================================================================
function C = apply_scheme(P, K, s)
%APPLY_SCHEME  三种对照加密方案
P = double(P); K = double(K); n = size(P,1);
switch s
    case 1   % P1：纯异或（无扩散）
        C = bitxor(uint8(P), uint8(K));
    case 2   % P2：单轮行内前向链式反馈（局部扩散，边界处不跨越）
        A = zeros(n,n);
        for i = 1:n
            A(i,1) = mod(P(i,1) + K(i,1), 256);
            for j = 2:n
                A(i,j) = mod(P(i,j) + K(i,j) + A(i,j-1), 256);
            end
        end
        C = uint8(A);
    case 3   % P3：双向链式反馈 + 多轮（充分扩散）
        % 用 cumsum 实现链式递推的向量化：
        %   正向行内：A(i,j) = Σ_{t≤j} (P(i,t)+K(i,t))  (mod 256)
        %   再叠加列向传播，交替若干轮
        A = mod(P + K, 256);
        for rd = 1:3
            A = mod(cumsum(A, 2), 256);            % 行内前向
            A = A - A(:, 1) + mod(A(:,1), 256);    % 归一（保持起点）
            A = mod(A, 256);
            A = mod(cumsum(A, 1), 256);            % 列向前向
            A = mod(A, 256);
            A = fliplr(A);  A = mod(cumsum(A, 2), 256);  A = fliplr(A);  % 行内反向
            A = flipud(A);  A = mod(cumsum(A, 1), 256);  A = flipud(A);  % 列向反向
        end
        C = uint8(mod(A, 256));
end
end

function [np, ua] = npcr_uaci(C1, C2)
C1 = double(C1); C2 = double(C2);
np = mean(C1(:) ~= C2(:));
ua = mean(abs(C1(:) - C2(:))) / 255;
end
