# Effective Key Entropy of Chaos-Based Image Ciphers — Reproduction Package

This archive contains the MATLAB source code, the standard test set, the raw
experimental outputs and the manuscript source for

> E. Zhu, "The Reversibility-Entropy Trade-off: Why Reversible Image Ciphers
> Cannot Retain Their Key Space."

It reproduces every table and figure of the experimental sections, together
with the two appendices of the paper. No proprietary data and no GPU are
required.

---

## 1. Requirements

| Item | Version used | Notes |
|---|---|---|
| MATLAB | R2025b | no toolbox function added after R2021b is used |
| Image Processing Toolbox | — | `imread`, `rgb2gray`, `imresize`, `imhist`, `conv2` |
| Statistics Toolbox | — | `histcounts`, `quantile`, `corr` (Spearman), `pdist` |
| Hardware | single CPU core | a few minutes for the full pipeline |

The test images `cameraman`, `circuit`, `rice`, `moon`, `trees`, `indiancorn`,
`printedtext` and `football` are read from the MATLAB installation
(`toolbox/images/imdata`). The six remaining images are synthesised in code,
so nothing has to be downloaded.

---

## 2. Directory layout

```
effective-key-entropy/
  lib/  testset_standard.m        standard test set (14 images, 256x256)
        heff_floatpath.m          path 1: floating-point resolution
        heff_periodpath.m         path 2: sequence period (Berlekamp-Massey)
        heff_distpath.m           path 3: distinguishability (sampling)
        heff_distpath_analytic.m  path 3: distinguishability (analytic)
  exp/  run_thm5_heff.m           three paths, convergence, compression
        run_criteria_audit.m      NPCR/UACI audit protocol
        make_figs_en.m            regenerates the English figures
  out/  csv / mat / txt          raw outputs
        en/                      English-labelled figures used in the paper
  paper/ main.tex, main.pdf      the manuscript
```

Two implementations of path 3 are shipped. `heff_distpath.m` is the sampling
version: it draws a finite number of keys and counts the equivalence classes
that a statistical distinguisher can separate. `heff_distpath_analytic.m` is
the analytic version and is the one actually invoked by `run_thm5_heff.m`,
because the sampling version caps the estimate at `log2(nKeys)` and would
impose an artificial ceiling on the convergence test. The sampling version is
kept for reference and for the equivalence-class study.

All paths are resolved relative to the location of the calling script, so the
archive can be unpacked anywhere and run without editing.

---

## 3. Reproduction

```matlab
addpath('lib','exp');
run_thm5_heff();        % tables: thm5_paths.csv, thm5_convergence.csv,
                        %         thm5_constraint.csv   + fig_thm5
run_criteria_audit();   % tables: audit_npcr_uaci.csv, audit_hypothesis.csv,
                        %         audit_correlation.csv + fig_audit
```

or in one line from the shell:

```bash
matlab -batch "addpath('lib','exp'); run_thm5_heff(); run_criteria_audit();"
```

The English-labelled figures in `out/en/` are regenerated with
`make_figs_en()`, which reads the cached MAT files.

**Staged execution.** `run_criteria_audit` accepts a stage argument:
`run_criteria_audit(1)` runs the NPCR/UACI measurements only, and
`run_criteria_audit(3)` runs the NPCR-versus-key-entropy correlation only.

---

## 4. What each experiment does

### `run_thm5_heff` — the reversibility-entropy trade-off

* **E1 — three independent measurement paths.** For three chaotic maps
  (Logistic `4x(1-x)`, Sine `sin(pi x)`, Tent `1-2|x-1/2|`) the effective key
  entropy is measured along three paths that share no common code:
  the floating-point resolution path, the sequence-period path
  (Berlekamp-Massey linear complexity), and the distinguishability path.
  Output: `thm5_paths.csv`.
* **E2 — convergence test.** The three paths should land within one order of
  magnitude; the spread and the max/min ratio are reported against the
  threshold of `10`. Output: `thm5_convergence.csv`.
* **E3 — compression by the reversibility constraint.** The same cipher is
  driven once from an unconstrained real-valued parameter and once from a
  parameter that has been quantised and made acyclic, so that the constraint is
  the only variable that changes. Output: `thm5_constraint.csv`.

### `run_criteria_audit` — audit protocol for the statistical layer

* **E1 — empirical distribution of NPCR/UACI.** Three schemes (P1 XOR-only,
  P2 row-diffuse, P3 full-diffuse) are each measured 200 times per image with
  the plaintext perturbed by a single pixel and the key held fixed, so that the
  spread of a single measurement is visible. Output: `audit_npcr_uaci.csv`.
* **E2 — hypothesis test against the ideal values.** Two-tailed `z` tests of
  the measured means against `NPCR* = 255/256` and `UACI* = 257/768` at
  `α = 0.05`. Output: `audit_hypothesis.csv`.
* **E3 — NPCR versus key entropy.** The effective key entropy is controlled by
  a seed of `nBits` bits (`4 → 32`) expanded into the full keystream by an LCG,
  and the Spearman correlation between `nBits` and NPCR is computed.
  Output: `audit_correlation.csv`.

---

## 5. Output files

| File | Contents |
|---|---|
| `thm5_paths.csv` | the three path values per map, plus `T_detect`, `LCratio`, `nEffBits`, `nTrials` |
| `thm5_convergence.csv` | spread (bit), ratio, convergence verdict |
| `thm5_constraint.csv` | nominal, float-path, dist-path, tightest unconstrained, joint bound and constrained values |
| `thm5_all.mat` | the three tables above as MATLAB `table` objects |
| `audit_npcr_uaci.csv` | NPCR/UACI mean, std and range per image and scheme |
| `audit_hypothesis.csv` | `z` statistics and the verdict at `α = 0.05` |
| `audit_correlation.csv` | Spearman `ρ`, `p`, entropy range, NPCR mean/std |
| `audit_all.mat` | the three tables above as MATLAB `table` objects |
| `en/fig1_heff_paths.*` | manuscript Fig. 1: three-path measurement and constraint compression |
| `en/fig2_audit.*` | manuscript Fig. 2: NPCR stability and NPCR versus key entropy |

The two PNG files in `out/en/` are byte-identical to `figs/fig1.png` and
`figs/fig2.png` used by the manuscript (87 508 and 152 922 bytes
respectively).

### Headline numbers reproduced by this package

Three paths (`thm5_paths.csv`): floating-point path `37.30` (Logistic),
`28.47` (Sine), `4.86` (Tent) bit; period path `15.29` bit for all three;
distinguishability path `52.00` bit for all three.

Convergence: Logistic and Sine have ratio `3.40` (converged); Tent has ratio
`10.70` and is the single non-converged case.

Constraint compression: tightest unconstrained `37.30` bit falls to
`8.00` bit (1 degree of freedom × 8 bits, capped by the joint bound
`min(52, log2 65536) = 16`), a reduction of `78.5 %`.

Audit: with the full-diffusion scheme the mean NPCR is `≈0.81` with a standard
deviation of `≈0.15`, and all fourteen images pass the two-tailed test against
the ideal values; the two weaker schemes fail. NPCR against key entropy gives
Spearman `ρ = −0.0322`, `p = 0.844`, i.e. no significant correlation — high
NPCR is not evidence of an adequate key space.

---

## 6. Reproducibility notes

1. **Determinism.** Seeds are fixed at the top of each driver:
   `rng(20261001)` in `run_thm5_heff`, `rng(20261002)` in
   `run_criteria_audit`, and `rng(20260930)` in the test-set synthesiser.
2. **Period-path ceiling.** `heff_periodpath` reports `log2(nSamples)` when no
   exact recurrence is detected within the lag window; the value `15.29` in
   `thm5_paths.csv` is `log2(40000)`, a lower bound on the true period rather
   than a measured period. It should be read as such.
3. **Hard-threshold sensitivity.** The `z` statistics in
   `audit_hypothesis.csv` are large for the weak schemes because the standard
   deviation is computed across 200 repeat measurements; the theoretical
   single-measurement standard deviations are `sd(NPCR) ≈ 0.000244` and
   `sd(UACI) ≈ 0.002381`. Both are reported in the log.
4. **Legacy log.** `p1_log.txt` in the working directory is a superseded run of
   an earlier revision of `run_criteria_audit.m`; it is not part of this
   package. The log shipped here, `out/p1_full_log.txt`, is the one produced by
   the current code.

---

## 7. Licence

Released under the MIT Licence (`SPDX-License-Identifier: MIT`). The MATLAB
test images are distributed with MATLAB and remain subject to the MathWorks
licence; they are read at run time from the local installation and are not
redistributed here.
